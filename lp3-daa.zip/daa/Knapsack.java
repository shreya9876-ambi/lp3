import java.util.Scanner;
public class Knapsack{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of items: ");
        int n = sc.nextInt();
        int[] weight = new int[n];
        int[] profit = new int[n];

        for(int i = 0; i < n; i++) {
            System.out.print("Enter weight and profit: ");
            weight[i] = sc.nextInt();
            profit[i] = sc.nextInt();
        }

        System.out.print("Enter bag capacity: ");
        int W = sc.nextInt();

        int[][] dp = new int[n + 1][W + 1];

        for(int i = 1; i <= n; i++) {
            for(int w = 1; w <= W; w++) {
                if(weight[i - 1] <= w) {
                    dp[i][w] = Math.max(profit[i - 1] + dp[i - 1][w - weight[i - 1]],dp[i - 1][w]);
                }else {
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }
        System.out.println("Maximum Profit: " + dp[n][W]);
        sc.close();
    }
}
